$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$repoRoot = Split-Path -Parent (Split-Path -Parent $projectRoot)
$toolchainRoot = Join-Path $repoRoot 'work\android-toolchain'
if ([string]::IsNullOrWhiteSpace($env:JAVA_HOME) -or !(Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) { $env:JAVA_HOME = Join-Path $toolchainRoot 'jdk-21' }
if ([string]::IsNullOrWhiteSpace($env:ANDROID_HOME) -or !(Test-Path (Join-Path $env:ANDROID_HOME 'platforms\android-36\android.jar'))) { $env:ANDROID_HOME = Join-Path $toolchainRoot 'sdk' }
$env:ANDROID_SDK_ROOT = $env:ANDROID_HOME
$env:PATH = "$env:JAVA_HOME\bin;$env:ANDROID_HOME\platform-tools;$env:PATH"

if (!(Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) { throw "JDK not found at $env:JAVA_HOME. See README.md." }
if (!(Test-Path (Join-Path $env:ANDROID_HOME 'platforms\android-36\android.jar'))) { throw "Android SDK API 36 not found at $env:ANDROID_HOME. See README.md." }

Push-Location (Join-Path $projectRoot 'android')
try {
    & .\gradlew.bat --no-daemon assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle debug build failed with exit code $LASTEXITCODE" }
} finally { Pop-Location }

$dist = Join-Path $repoRoot 'dist'
New-Item -ItemType Directory -Path $dist -Force | Out-Null
Copy-Item (Join-Path $projectRoot 'android\app\build\outputs\apk\debug\app-debug.apk') (Join-Path $dist 'View-Spends-debug.apk') -Force
Write-Host "Built $dist\View-Spends-debug.apk"

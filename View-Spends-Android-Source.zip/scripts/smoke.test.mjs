import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { test } from 'node:test';
import { JSDOM, VirtualConsole } from 'jsdom';

const htmlPath = process.env.VIEW_SPENDS_TEST_HTML || new URL('../src/index.html', import.meta.url);
const html = await readFile(htmlPath, 'utf8');
const storageKey = 'view-spends-personal-offline-v1';

function createApp(seed = null) {
  const errors = [];
  const downloads = [];
  const virtualConsole = new VirtualConsole();
  virtualConsole.on('jsdomError', error => errors.push(error.message));
  const dom = new JSDOM(html, {
    url: 'https://view-spends.test/',
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    virtualConsole,
    beforeParse(window) {
      window.confirm = () => true;
      window.prompt = (_message, value) => value ?? '';
      window.scrollTo = () => {};
      window.HTMLElement.prototype.scrollIntoView = () => {};
      window.requestAnimationFrame = callback => window.setTimeout(() => callback(Date.now()), 0);
      window.HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
      window.HTMLDialogElement.prototype.close = function () {
        this.removeAttribute('open');
        this.dispatchEvent(new window.Event('close'));
      };
      window.HTMLAnchorElement.prototype.click = function () {
        downloads.push({ filename: this.download, href: this.href });
      };
      window.URL.createObjectURL = blob => {
        window.__exportBlob = blob;
        return 'blob:view-spends-test';
      };
      window.URL.revokeObjectURL = () => {};
      window.HTMLCanvasElement.prototype.getBoundingClientRect = function () {
        return { width: this.id === 'chart' ? 500 : 540, height: this.id === 'chart' ? 205 : 325, top: 0, left: 0, right: 540, bottom: 325 };
      };
      window.HTMLCanvasElement.prototype.getContext = function () {
        return new Proxy({}, { get: (target, key) => target[key] ?? (() => {}), set: (target, key, value) => (target[key] = value, true) });
      };
      window.HTMLCanvasElement.prototype.toBlob = function (callback, type) {
        callback(new window.Blob(['test image'], { type: type || 'image/png' }));
      };
      if (seed) window.localStorage.setItem(storageKey, JSON.stringify(seed));
    },
  });
  return { dom, window: dom.window, errors, downloads };
}

function dispatch(window, element, type) {
  element.dispatchEvent(new window.Event(type, { bubbles: true, cancelable: true }));
}

function addEntry(app, { type = 'expense', amount, category, note = '', date }) {
  const { window } = app;
  if (type === 'income') window.document.querySelector('[data-type="income"]').click();
  window.document.getElementById('amount').value = String(amount);
  window.document.getElementById('category').value = category;
  window.document.getElementById('date').value = date;
  window.document.getElementById('note').value = note;
  dispatch(window, window.document.getElementById('entryForm'), 'submit');
}

function stateOf(window) {
  return JSON.parse(window.localStorage.getItem(storageKey));
}

function fileText(window, blob) {
  return new Promise((resolve, reject) => {
    const reader = new window.FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsText(blob);
  });
}

test('View Spends core flows persist locally and remain safe with hostile text', async () => {
  const app = createApp();
  const { window, errors, downloads } = app;
  const { document } = window;
  document.getElementById('skipSetup').click();
  const day = new Date().toISOString().slice(0, 10);

  addEntry(app, { amount: 12.5, category: 'Food', note: 'lunch', date: day });
  addEntry(app, { type: 'income', amount: 2000, category: 'Salary', note: 'pay', date: day });
  assert.equal(stateOf(window).expenses.length, 2, 'expense and income both save');
  assert.ok(document.querySelector('#balanceHero').textContent.includes('Money received minus money spent'));
  assert.match(document.querySelector('#summaryCards').textContent, /DAILY AVERAGE/);
  assert.match(document.querySelector('#summaryCards').textContent, /THIS WEEK/);
  assert.match(document.querySelector('#summaryCards').textContent, /THIS MONTH/);
  assert.match(document.querySelector('#summaryCards').textContent, /THIS YEAR/);
  assert.ok(document.querySelector('#chart').getContext('2d'), 'comparison chart initializes');
  assert.match(document.querySelector('#categoryBreakdown').textContent, /Food/);

  document.getElementById('searchTransactions').value = 'lunch';
  dispatch(window, document.getElementById('searchTransactions'), 'input');
  assert.equal(document.querySelectorAll('#expenseRows tr').length, 1, 'search filters activity');
  document.getElementById('searchTransactions').value = 'no such entry';
  dispatch(window, document.getElementById('searchTransactions'), 'input');
  assert.equal(document.querySelectorAll('#expenseRows tr').length, 0, 'empty search result is safe');
  document.getElementById('clearFilters').click();

  [...document.querySelectorAll('#expenseRows tr')]
    .find(row => row.textContent.includes('lunch'))
    .querySelector('[data-edit]').click();
  assert.equal(document.getElementById('entryTitle').textContent, 'Edit transaction');
  document.getElementById('amount').value = '15';
  document.getElementById('note').value = 'lunch updated';
  dispatch(window, document.getElementById('entryForm'), 'submit');
  assert.equal(stateOf(window).expenses.find(entry => entry.type === 'expense').amount, 15, 'edit updates the saved row');

  [...document.querySelectorAll('#expenseRows tr')]
    .find(row => row.textContent.includes('lunch updated'))
    .querySelector('[data-delete]').click();
  assert.equal(stateOf(window).expenses.length, 1, 'delete removes the entry');
  document.getElementById('undoDelete').click();
  assert.equal(stateOf(window).expenses.length, 2, 'undo restores the entry');

  const categoryForm = document.getElementById('categoryForm');
  document.getElementById('newCategory').value = '<img src=x onerror=alert(1)> Test';
  document.getElementById('newCategoryIcon').value = '🧪';
  dispatch(window, categoryForm, 'submit');
  assert.ok(stateOf(window).categories.includes('<img src=x onerror=alert(1)> Test'));
  assert.equal(document.querySelector('#categoryList img'), null, 'category text is escaped in the UI');

  document.getElementById('settingsBtn').click();
  document.getElementById('backupBtn').click();
  assert.ok(downloads.some(file => file.filename.endsWith('.json')), 'JSON backup invokes a file download');
  const backup = JSON.parse(await fileText(window, window.__exportBlob));
  assert.equal(backup.expenses.length, 2, 'backup includes real transaction records');
  assert.equal(backup.categories.includes('<img src=x onerror=alert(1)> Test'), true);

  const imported = { ...backup, expenses: [{ id: 'restored', amount: 7, currency: 'USD', type: 'expense', date: day, category: 'Food', note: 'restored row' }] };
  const importInput = document.getElementById('importFile');
  Object.defineProperty(importInput, 'files', { configurable: true, value: [{ text: async () => JSON.stringify(imported) }] });
  dispatch(window, importInput, 'change');
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.equal(stateOf(window).expenses.length, 1, 'restore imports a complete backup');
  assert.equal(stateOf(window).expenses[0].id, 'restored');

  const reload = createApp(stateOf(window));
  assert.equal(stateOf(reload.window).expenses[0].note, 'restored row', 'data survives app restart');
  assert.equal(errors.length, 0, `no JavaScript errors: ${errors.join('; ')}`);
  reload.dom.window.close();
  app.dom.window.close();
});

test('CSV formula text is neutralized before spreadsheet export', async () => {
  const app = createApp();
  const { window, downloads } = app;
  window.document.getElementById('skipSetup').click();
  addEntry(app, { amount: 1, category: 'Other', note: '=HYPERLINK("https://evil.invalid")', date: new Date().toISOString().slice(0, 10) });
  window.document.getElementById('exportBtn').click();
  assert.ok(downloads.some(file => file.filename.endsWith('.csv')));
  const csv = await fileText(window, window.__exportBlob);
  assert.match(csv, /'=HYPERLINK/);
  app.dom.window.close();
});

test('malformed and hostile backup data is sanitized before it reaches the UI', async () => {
  const app = createApp();
  const { window, errors } = app;
  window.document.getElementById('skipSetup').click();
  const hostile = {
    currency: '<script>',
    categories: [null, 17, '"><img src=x onerror=alert(1)>'],
    categoryIcons: { '"><img src=x onerror=alert(1)>': '<img src=x onerror=alert(2)>' },
    expenses: [
      { id: 'bad-date', amount: 99, currency: 'USD', date: { toString: 'not a date' }, category: 'Injected', note: 'must be dropped' },
      { id: 'hostile', amount: '1e9999', currency: '<svg>', date: new Date().toISOString().slice(0, 10), category: '"><img src=x onerror=alert(1)>', note: '<script>alert(1)</script>' },
    ],
    recurring: [{ id: 'bad-recurring', amount: 100, name: '<img src=x>', nextDate: { value: 'today' } }],
    goals: [null, { id: 'goal', name: '<svg onload=alert(1)>', icon: '<img>', target: 'Infinity', saved: -10 }],
  };
  const input = window.document.getElementById('importFile');
  Object.defineProperty(input, 'files', { configurable: true, value: [{ text: async () => JSON.stringify(hostile) }] });
  dispatch(window, input, 'change');
  await new Promise(resolve => setTimeout(resolve, 0));
  const state = stateOf(window);
  assert.equal(state.expenses.length, 1, 'invalid transaction dates are dropped');
  assert.equal(state.expenses[0].amount, 0, 'non-finite amounts cannot poison totals');
  assert.equal(state.expenses[0].currency, 'USD', 'unsupported currency codes are replaced safely');
  assert.deepEqual(state.recurring, [], 'invalid recurring dates cannot create surprise entries');
  assert.equal(window.document.querySelector('#categoryList img, #categoryList svg'), null, 'hostile category text and custom icons remain escaped');
  assert.equal(window.document.querySelector('#goalList img, #goalList svg'), null, 'goal fields remain escaped');
  assert.ok(Number.isFinite(state.monthlyBudget), 'numeric settings stay finite');
  assert.equal(errors.length, 0, `hostile backup causes no JavaScript errors: ${errors.join('; ')}`);
  app.dom.window.close();
});

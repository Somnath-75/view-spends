from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
icon_path = root / 'src' / 'icon-512.png'
if not icon_path.exists():
    raise SystemExit(f'Missing app icon: {icon_path}')

source = Image.open(icon_path).convert('RGBA')
pixels = source.load()
background = pixels[0, 0]
for y in range(source.height):
    for x in range(source.width):
        r, g, b, a = pixels[x, y]
        if (abs(r-background[0]) + abs(g-background[1]) + abs(b-background[2])) < 38 and g > r * 1.12:
            pixels[x, y] = (r, g, b, 0)

bounds = source.getbbox()
mark = source.crop(bounds)
mark.thumbnail((330, 330), Image.Resampling.LANCZOS)
foreground = Image.new('RGBA', (432, 432), (0, 0, 0, 0))
foreground.alpha_composite(mark, ((432-mark.width)//2, (432-mark.height)//2))

res = root / 'android' / 'app' / 'src' / 'main' / 'res'
legacy = { 'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192 }
adaptive = { 'mdpi': 108, 'hdpi': 162, 'xhdpi': 216, 'xxhdpi': 324, 'xxxhdpi': 432 }
for density, size in legacy.items():
    folder = res / f'mipmap-{density}'
    folder.mkdir(parents=True, exist_ok=True)
    source.resize((size, size), Image.Resampling.LANCZOS).save(folder / 'ic_launcher.png')
    source.resize((size, size), Image.Resampling.LANCZOS).save(folder / 'ic_launcher_round.png')
for density, size in adaptive.items():
    folder = res / f'mipmap-{density}'
    folder.mkdir(parents=True, exist_ok=True)
    foreground.resize((size, size), Image.Resampling.LANCZOS).save(folder / 'ic_launcher_foreground.png')

print('Generated launcher icon resources from the existing VS branding.')

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$repoRoot = Split-Path -Parent (Split-Path -Parent $projectRoot)
$toolchainRoot = Join-Path $repoRoot 'work\android-toolchain'
if ([string]::IsNullOrWhiteSpace($env:JAVA_HOME) -or !(Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) { $env:JAVA_HOME = Join-Path $toolchainRoot 'jdk-21' }
if ([string]::IsNullOrWhiteSpace($env:ANDROID_HOME) -or !(Test-Path (Join-Path $env:ANDROID_HOME 'platforms\android-36\android.jar'))) { $env:ANDROID_HOME = Join-Path $toolchainRoot 'sdk' }
$env:ANDROID_SDK_ROOT = $env:ANDROID_HOME
$env:PATH = "$env:JAVA_HOME\bin;$env:ANDROID_HOME\platform-tools;$env:PATH"

$secretRoot = Join-Path $env:USERPROFILE '.codex\view-spends-signing'
$keystore = Join-Path $secretRoot 'view-spends-release.jks'
$protectedPassword = Join-Path $secretRoot 'password.dpapi'
if (!(Test-Path $keystore) -or !(Test-Path $protectedPassword)) {
    throw "Release key or protected password is missing. Keep them at $secretRoot. See SIGNING.md."
}
$encrypted = (Get-Content -LiteralPath $protectedPassword -Raw).Trim()
$securePassword = ConvertTo-SecureString -String $encrypted
$credential = [System.Net.NetworkCredential]::new('', $securePassword)
$env:VIEW_SPENDS_KEYSTORE = $keystore
$env:VIEW_SPENDS_KEYSTORE_PASSWORD = $credential.Password
$env:VIEW_SPENDS_KEY_PASSWORD = $credential.Password
$env:VIEW_SPENDS_KEY_ALIAS = 'viewspends'

if (!(Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) { throw "JDK not found at $env:JAVA_HOME. See README.md." }
Push-Location (Join-Path $projectRoot 'android')
try {
    & .\gradlew.bat --no-daemon assembleRelease
    if ($LASTEXITCODE -ne 0) { throw "Gradle release build failed with exit code $LASTEXITCODE" }
} finally {
    Pop-Location
    Remove-Item Env:\VIEW_SPENDS_KEYSTORE,Env:\VIEW_SPENDS_KEYSTORE_PASSWORD,Env:\VIEW_SPENDS_KEY_PASSWORD,Env:\VIEW_SPENDS_KEY_ALIAS -ErrorAction SilentlyContinue
}

$dist = Join-Path $repoRoot 'dist'
New-Item -ItemType Directory -Path $dist -Force | Out-Null
Copy-Item (Join-Path $projectRoot 'android\app\build\outputs\apk\release\app-release.apk') (Join-Path $dist 'View-Spends.apk') -Force
Write-Host "Built signed APK: $dist\View-Spends.apk"

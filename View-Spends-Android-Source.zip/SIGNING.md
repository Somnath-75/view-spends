# Release signing key

The release signing key is stored outside this source project at:

`%USERPROFILE%\.codex\view-spends-signing\view-spends-release.jks`

Its strong generated password is encrypted with Windows DPAPI in `password.dpapi`. The release script decrypts it only into the Gradle process environment and clears those environment values afterward. No signing password is checked into this project.

**Back up the `.jks` file and its password securely.** The DPAPI password file can only be decrypted by this same Windows user on this same Windows installation. For a disaster-recovery copy on another device, store the keystore password separately in your password manager; do not put it in the APK, source ZIP, or a public repository. If the key is lost, Android will not accept future updates over this release.

Use `pnpm android:release` from this project to create future signed builds on this PC.

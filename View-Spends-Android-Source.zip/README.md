# View Spends for Android

Capacitor Android project that packages the existing single-file offline app in a local WebView. Runtime data stays in WebView `localStorage` inside the app's private storage. No account, server, analytics, network connection, or AI is used. Android cloud/device backup is disabled.

The source HTML is `src/index.html`. Capacitor file export uses the Android Sharesheet for CSV, JSON backups, and share-card images; JSON import remains in the app's file picker.

## Build

Requirements: Node.js 22+, pnpm, Java 21, Android SDK Platform 36 and Build Tools 36.0.0, plus PowerShell 7 (`pwsh`).

```powershell
pnpm install
pnpm android:debug
```

The debug APK is written to `../dist/View-Spends-debug.apk`.

For a release APK, first configure the release signing key using the private instructions in `SIGNING.md`, then run:

```powershell
pnpm android:release
```

The release APK is written to `../dist/View-Spends.apk`.

## Permissions and offline behavior

The merged manifest requests no internet or network-state permission; AndroidX contributes one internal receiver permission. File exports use private app cache and Android's Sharesheet; importing uses the system file picker. No contacts, camera, microphone, location, calls, SMS, or broad storage access is requested. User entries stay in app-private WebView storage and Android's automatic backup is disabled.

The app has no sign-in or cross-device sync. To move data, export a JSON backup on one device and import it on the other.

## Contributing

Contributions are welcome from any coder. Fork the repository, make your changes on a branch, run `pnpm test` and `pnpm run build`, then open a pull request. Bug reports, accessibility improvements, documentation updates, and feature ideas are welcome. Please do not include private spending data, signing keys, or passwords in issues or pull requests.

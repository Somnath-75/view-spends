import { Directory, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

function toBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error || new Error('Could not read export file'));
    reader.onload = () => resolve(String(reader.result).split(',', 2)[1]);
    reader.readAsDataURL(blob);
  });
}

window.ViewSpendsAndroid = {
  async shareFile(blob, filename) {
    const data = await toBase64(blob);
    const file = await Filesystem.writeFile({
      path: filename,
      data,
      directory: Directory.Cache,
      recursive: true,
    });
    await Share.share({
      title: filename,
      text: `View Spends export: ${filename}`,
      files: [file.uri],
      dialogTitle: 'Save or share your export',
    });
  },
};

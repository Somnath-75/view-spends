package com.stark.viewspends;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

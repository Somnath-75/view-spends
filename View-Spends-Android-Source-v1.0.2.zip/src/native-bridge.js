import { App } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { Directory, Filesystem } from '@capacitor/filesystem';
import { Preferences } from '@capacitor/preferences';
import { Share } from '@capacitor/share';
import { selectSavedState } from './storage-recovery.mjs';

const stateKey = 'view-spends-personal-offline-v1';
const backupKey = 'view-spends-durable-state-v1';
let writeQueue = Promise.resolve();

function parseState(raw) {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw);
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

function enqueueNativeSnapshot(serialized) {
  if (!Capacitor.isNativePlatform() || typeof serialized !== 'string' || !serialized) return writeQueue;
  const state = parseState(serialized);
  if (!state) return Promise.reject(new Error('Saved spending data is not valid JSON.'));
  const savedAt = Number(state._savedAt) || Date.now();
  const snapshot = JSON.stringify({ savedAt, state: serialized });
  writeQueue = writeQueue
    .catch(() => {})
    .then(() => Preferences.set({ key: backupKey, value: snapshot }));
  return writeQueue;
}

async function restoreOrSeedNativeSnapshot() {
  if (!Capacitor.isNativePlatform()) return;

  const [{ value: backupValue }, currentRaw] = await Promise.all([
    Preferences.get({ key: backupKey }),
    Promise.resolve(localStorage.getItem(stateKey)),
  ]);
  const recovery = selectSavedState(currentRaw, backupValue);

  // Recover the newer native snapshot before the dashboard or setup screen can
  // accept input, so fresh setup cannot overwrite a recoverable month.
  if (recovery.action === 'restore') {
    localStorage.setItem(stateKey, recovery.raw);
    location.reload();
    return false;
  }

  // Give legacy localStorage saves a timestamp and immediately establish a
  // native copy when upgrading from an earlier APK.
  const currentState = parseState(recovery.raw);
  let normalizedCurrentRaw = recovery.raw;
  if (currentState && !Number(currentState._savedAt)) {
    currentState._savedAt = Date.now();
    normalizedCurrentRaw = JSON.stringify(currentState);
    localStorage.setItem(stateKey, normalizedCurrentRaw);
  }
  if (normalizedCurrentRaw) await enqueueNativeSnapshot(normalizedCurrentRaw);
  return true;
}

async function initializeStorage() {
  let ready = true;
  try {
    ready = await restoreOrSeedNativeSnapshot();
  } catch (error) {
    console.error('Native save setup failed; browser storage remains available.', error);
  }
  if (ready) window.__resolveViewSpendsNativeStorageReady?.();
}

window.addEventListener('view-spends-state-saved', event => {
  enqueueNativeSnapshot(event.detail).catch(error => {
    console.error('Native backup could not be saved.', error);
    window.dispatchEvent(new CustomEvent('view-spends-native-save-error'));
  });
});

function flushLatestState() {
  try {
    const latest = localStorage.getItem(stateKey);
    if (latest) enqueueNativeSnapshot(latest).catch(error => console.error('Native save flush failed.', error));
  } catch (error) {
    console.error('Local data could not be read for native save.', error);
  }
}

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') flushLatestState();
});
App.addListener('appStateChange', ({ isActive }) => {
  if (!isActive) flushLatestState();
}).catch(error => console.info('App lifecycle save hook unavailable.', error));

function toBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error || new Error('Could not read export file'));
    reader.onload = () => resolve(String(reader.result).split(',', 2)[1]);
    reader.readAsDataURL(blob);
  });
}

window.ViewSpendsAndroid = {
  async shareFile(blob, filename) {
    const data = await toBase64(blob);
    const file = await Filesystem.writeFile({
      path: filename,
      data,
      directory: Directory.Cache,
      recursive: true,
    });
    await Share.share({
      title: filename,
      text: `View Spends export: ${filename}`,
      files: [file.uri],
      dialogTitle: 'Save or share your export',
    });
  },
};

void initializeStorage();

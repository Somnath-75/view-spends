function parseObject(raw) {
  if (typeof raw !== 'string' || !raw) return null;
  try {
    const value = JSON.parse(raw);
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

function parseBackup(raw) {
  if (typeof raw !== 'string' || !raw) return null;
  const parsed = parseObject(raw);
  if (typeof parsed?.state === 'string') {
    const state = parseObject(parsed.state);
    if (!state) return null;
    return {
      raw: parsed.state,
      state,
      savedAt: Number(parsed.savedAt) || Number(state._savedAt) || 0,
    };
  }

  // Older builds may have stored the state directly instead of in an envelope.
  if (!parsed) return null;
  return { raw, state: parsed, savedAt: Number(parsed._savedAt) || 0 };
}

export function selectSavedState(currentRaw, backupRaw) {
  const current = parseObject(currentRaw);
  const backup = parseBackup(backupRaw);
  const currentSavedAt = Number(current?._savedAt) || 0;

  if (backup && (!current || backup.savedAt > currentSavedAt)) {
    return { action: 'restore', raw: backup.raw };
  }
  if (current) return { action: 'keep', raw: currentRaw };
  return { action: 'empty', raw: null };
}
